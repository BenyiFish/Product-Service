package com.ecomarket.Product_Service.ServiceTest;

import com.ecomarket.Product_Service.exception.ResourceNotFoundException;
import com.ecomarket.Product_Service.model.Product;
import com.ecomarket.Product_Service.repository.ProductRepository;
import com.ecomarket.Product_Service.service.ProductServiceImpl;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

public class ProductServiceTest {

    private ProductRepository repository;
    private ProductServiceImpl service;

    private Product productoDummy;

    @BeforeEach
    void setUp() {
        repository = mock(ProductRepository.class);
        service = new ProductServiceImpl(repository);

        productoDummy = new Product();
        productoDummy.setId(1L);
        productoDummy.setName("Notebook");
        productoDummy.setDescription("Asus VivoBook");
        productoDummy.setPrice(600000);
        productoDummy.setStock(15);
        productoDummy.setCategory("Electronicos");
    }

    @Test
    @DisplayName("Debe crear un producto correctamente")
    void testCreate() {
        when(repository.save(productoDummy)).thenReturn(productoDummy);

        Product result = service.create(productoDummy);

        assertNotNull(result);
        assertEquals("Notebook", result.getName());
    }

    @Test
    @DisplayName("Debe obtener un producto por ID si existe")
    void testGetByIdExistente() {
        when(repository.findById(1L)).thenReturn(Optional.of(productoDummy));

        Product result = service.getById(1L);

        assertNotNull(result);
        assertEquals(1L, result.getId());
        assertEquals("Notebook", result.getName());
    }

    @Test
    @DisplayName("Debe lanzar excepción si el producto no existe")
    void testGetByIdNoExistente() {
        when(repository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> service.getById(99L));
    }

    @Test
    @DisplayName("Debe devolver lista de todos los productos")
    void testGetAll() {
        Product otro = new Product();
        otro.setId(2L);
        otro.setName("Mouse");
        otro.setDescription("Logitech");
        otro.setPrice(20000);
        otro.setStock(30);
        otro.setCategory("Electronicos");

        when(repository.findAll()).thenReturn(Arrays.asList(productoDummy, otro));

        List<Product> productos = service.getAll();

        assertEquals(2, productos.size());
        assertEquals("Mouse", productos.get(1).getName());
    }

    @Test
    @DisplayName("Debe actualizar un producto si existe")
    void testUpdateProductoExistente() {
        Product actualizado = new Product();
        actualizado.setName("Notebook Gamer");
        actualizado.setDescription("Asus ROG");
        actualizado.setPrice(800000);
        actualizado.setStock(10);
        actualizado.setCategory("Electronicos");

        when(repository.findById(1L)).thenReturn(Optional.of(productoDummy));
        when(repository.save(any(Product.class))).thenAnswer(i -> i.getArgument(0));

        Product result = service.update(1L, actualizado);

        assertNotNull(result);
        assertEquals("Notebook Gamer", result.getName());
        assertEquals(800000, result.getPrice());
    }

    @Test
    @DisplayName("Debe lanzar excepción al actualizar producto no existente")
    void testUpdateProductoNoExistente() {
        Product actualizado = new Product();
        actualizado.setName("Otro");

        when(repository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(RuntimeException.class, () -> service.update(99L, actualizado));
    }

    @Test
    @DisplayName("Debe eliminar un producto correctamente")
    void testDelete() {
        doNothing().when(repository).deleteById(1L);

        assertDoesNotThrow(() -> service.delete(1L));

        verify(repository, times(1)).deleteById(1L);
    }

    @Test
    @DisplayName("Debe devolver productos por categoría")
    void testGetByCategory() {
        when(repository.findByCategory("Electronicos"))
                .thenReturn(Collections.singletonList(productoDummy));

        List<Product> resultado = service.getByCategory("Electronicos");

        assertEquals(1, resultado.size());
        assertEquals("Notebook", resultado.get(0).getName());
    }

    @Test
    @DisplayName("Debe devolver lista vacía si no hay productos en la categoría")
    void testGetByCategoryVacia() {
        when(repository.findByCategory("Ropa")).thenReturn(Collections.emptyList());

        List<Product> resultado = service.getByCategory("Ropa");

        assertTrue(resultado.isEmpty());
    }
}
package com.ecomarket.Product_Service.ControllerTest;

import com.ecomarket.Product_Service.controller.ProductController;
import com.ecomarket.Product_Service.model.Product;
import com.ecomarket.Product_Service.model.ProductModel;
import com.ecomarket.Product_Service.assembler.ProductModelAssembler;
import com.ecomarket.Product_Service.service.ProductService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.hateoas.Link;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.http.MediaType;

import java.util.List;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(ProductController.class)
public class ProductControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ProductService productService;

    @MockBean
    private ProductModelAssembler assembler;

    @Autowired
    private ObjectMapper objectMapper;

    // Dummy ProductModel con HATEOAS
    public static class ProductModelDummy extends ProductModel {
        public ProductModelDummy(Product p) {
            this.setId(p.getId());
            this.setName(p.getName());
            this.setDescription(p.getDescription());
            this.setPrice(p.getPrice());
            this.setStock(p.getStock());
            this.setCategory(p.getCategory());
            this.add(Link.of("http://localhost/api/products/" + p.getId()).withSelfRel());
        }
    }

    @Test
    @DisplayName("POST /api/products crea producto correctamente")
    public void testCrearProducto() throws Exception {
        Product input = Product.builder()
                .name("Manzana")
                .description("Fruta dulce")
                .price(1000.0)
                .stock(10)
                .category("Frutas")
                .build();

        Product saved = Product.builder()
                .id(1L)
                .name("Manzana")
                .description("Fruta dulce")
                .price(1000.0)
                .stock(10)
                .category("Frutas")
                .build();

        when(productService.create(any(Product.class))).thenReturn(saved);
        when(assembler.toModel(any(Product.class))).thenReturn(new ProductModelDummy(saved));

        mockMvc.perform(post("/api/products")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(input)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.name").value("Manzana"))
                .andExpect(jsonPath("$.id").value(1));
    }

    @Test
    @DisplayName("GET /api/products/{id} devuelve producto existente")
    public void testGetProductoPorIdExistente() throws Exception {
        Product producto = Product.builder()
                .id(2L)
                .name("Pera")
                .description("Fruta jugosa")
                .price(800.0)
                .stock(5)
                .category("Frutas")
                .build();

        when(productService.getById(2L)).thenReturn(producto);
        when(assembler.toModel(any(Product.class))).thenReturn(new ProductModelDummy(producto));

        mockMvc.perform(get("/api/products/2"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("Pera"));
    }

    @Test
    @DisplayName("GET /api/products/{id} producto no encontrado")
    public void testGetProductoNoExistente() throws Exception {
        when(productService.getById(99L)).thenThrow(new RuntimeException("Producto no encontrado"));

        mockMvc.perform(get("/api/products/99"))
                .andExpect(status().isBadRequest());
    }

    @Test
    @DisplayName("GET /api/products retorna lista de productos")
    public void testGetTodosProductos() throws Exception {
        Product p = Product.builder()
                .id(3L)
                .name("Plátano")
                .description("Fruta tropical")
                .price(1100.0)
                .stock(7)
                .category("Frutas")
                .build();

        when(productService.getAll()).thenReturn(List.of(p));
        when(assembler.toModel(any(Product.class))).thenReturn(new ProductModelDummy(p));

        mockMvc.perform(get("/api/products"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$._embedded.productModelDummyList[0].name").value("Plátano"));

    }

    @Test
    @DisplayName("PUT /api/products/{id} actualiza producto")
    public void testActualizarProducto() throws Exception {
        Product actualizado = Product.builder()
                .id(4L)
                .name("Durazno")
                .description("Fruta con hueso")
                .price(900.0)
                .stock(6)
                .category("Frutas")
                .build();

        when(productService.update(eq(4L), any(Product.class))).thenReturn(actualizado);
        when(assembler.toModel(any(Product.class))).thenReturn(new ProductModelDummy(actualizado));

        mockMvc.perform(put("/api/products/4")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(actualizado)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("Durazno"));
    }

    @Test
    @DisplayName("PUT /api/products/{id} retorna 404 si producto no existe")
    public void testActualizarProductoNoEncontrado() throws Exception {
        when(productService.update(eq(88L), any(Product.class))).thenReturn(null);

        mockMvc.perform(put("/api/products/88")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(Product.builder().build())))
                .andExpect(status().isNotFound());
    }

    @Test
    @DisplayName("DELETE /api/products/{id} elimina producto")
    public void testEliminarProducto() throws Exception {
        doNothing().when(productService).delete(5L);

        mockMvc.perform(delete("/api/products/5"))
                .andExpect(status().isNoContent());
    }

    @Test
    @DisplayName("GET /api/products/category/{category} devuelve productos por categoría")
    public void testGetPorCategoria() throws Exception {
        Product p = Product.builder()
                .id(6L)
                .name("Kiwi")
                .description("Verde con semillas")
                .price(1300.0)
                .stock(4)
                .category("Frutas")
                .build();

        when(productService.getByCategory("Frutas")).thenReturn(List.of(p));
        when(assembler.toModel(any(Product.class))).thenReturn(new ProductModelDummy(p));

        mockMvc.perform(get("/api/products/category/Frutas"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$._embedded.productModelDummyList[0].name").value("Kiwi"));

    }

    @Test
    @DisplayName("GET /api/products/category/{category} retorna 400 si no hay productos")
    public void testGetPorCategoriaVacia() throws Exception {
        when(productService.getByCategory("Electrodomésticos")).thenReturn(List.of());

        mockMvc.perform(get("/api/products/category/Electrodomésticos"))
                .andExpect(status().isBadRequest());
    }
}
